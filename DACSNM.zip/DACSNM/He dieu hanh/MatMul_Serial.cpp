#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <float.h>

int main(int argc, char *argv[]) {
    int **a, **b, **c;
    int a_r, a_c, b_r, b_c;
    clock_t start, end; 
    double dif; 
    
again:
    printf("\nEnter rows and columns for 1st matrix: ");
    scanf("%d%d", &a_r, &a_c);
    printf("\nEnter rows and columns for 2nd matrix: ");
    scanf("%d%d", &b_r, &b_c);
    if (a_c != b_r) {
        printf("\nCan not multiply");
        goto again;
    }
    /* allocate memory for matrix one */
    a = (int **) malloc(sizeof(int*) * a_r);
    for (int i = 0; i < a_c; i++) {
        a[i] = (int *) malloc(sizeof(int) * a_c);
    }
    /* allocate memory for matrix two */
    b = (int **) malloc(sizeof(int*) * b_r);
    for (int i = 0; i < b_c; i++) {
        b[i] = (int *) malloc(sizeof(int) *  b_c);
    }
    /* allocate memory for sum matrix */
    c = (int **) malloc(sizeof(float*) *  a_r);
    for (int i = 0; i < b_c; i++) {
        c[i] = (int *) malloc(sizeof(int) *  b_c);
    }
    printf("Initializing matrices...\n");
    
    start = clock(); //start the timer
    //initializing first matrix
    for (int i = 0; i < a_r; i++) {
        for (int j = 0; j < a_c; j++) {
            a[i][j] = i + j;
        }
    }
    // initializing second matrix
    for (int i = 0; i < b_r; i++) {
        for (int j = 0; j < b_c; j++) {
            b[i][j] = i*j;
        }
    }
    /*initialize product matrix */
    for (int i = 0; i < a_r; i++) {
        for (int j = 0; j < b_c; j++) {
            c[i][j] = 0;
        }
    }
    /* multiply matrix one and matrix two */
    for (int i = 0; i < a_r; i++) {
        for (int j = 0; j < b_c; j++) {
            for (int k = 0; k < b_r; k++) {
                c[i][j] = c[i][j] + a[i][k] * b[k][j];
            }
        }
    }

    printf("******************************************************\n");
    printf("Done.\n");
    end = clock(); //end the timer
    dif = ((double) (end - start)) / CLOCKS_PER_SEC; //store the difference
    printf("Serialization took %f sec. time.\n", dif);
    
//    for (int i = 0; i < a_r; i++) {
//        for (int j = 0; j < b_c; j++) {
//            printf("%d\t",c[i][j]);
//        }
//        printf("\n");
//    }

    for (int i = 0; i < a_r; i++) {
        free(a[i]);
    }
    free(a);
    for (int i = 0; i < a_c; i++) {
        free(b[i]);
    }
    free(b);
    for (int i = 0; i < b_c; i++) {
        free(c[i]);
    }
    free(c);
}
